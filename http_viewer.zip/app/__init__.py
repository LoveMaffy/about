from flask import Flask
from flask_session import Session
from .config import Config
import datetime

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    

    Session(app)
    

    @app.template_filter('timestamp_to_datetime')
    def timestamp_to_datetime(timestamp):
        try:
            ts = float(timestamp)
            dt = datetime.datetime.fromtimestamp(ts)
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            return timestamp

    from .routes.main import main_bp
    from .routes.detail import detail_bp
    from .routes.database_selector import db_selector_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(detail_bp)
    app.register_blueprint(db_selector_bp)

    return app
