import os

class Config:
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DB_DIR = os.path.join(BASE_DIR, "..", "db_log")
    # 默认数据库路径
    DEFAULT_DB_PATH = os.path.join(DB_DIR, "http.db")
    
    # Session配置 - 调整配置以避免类型不匹配问题
    SECRET_KEY = "strong-secret-key-for-session-management-2023"
    SESSION_TYPE = "filesystem"
    SESSION_PERMANENT = False  # 改为False避免长期存储可能导致的问题
    SESSION_USE_SIGNER = False  # 临时禁用签名以避免潜在的类型转换问题
    # 设置session文件保存路径
    SESSION_FILE_DIR = os.path.join(BASE_DIR, "..", "flask_session")
    # 添加额外配置以确保兼容性
    SESSION_FILE_THRESHOLD = 250  # 增加阈值以减少文件操作
    SESSION_FILE_MODE = 0o600  # 设置合适的文件权限
    # 确保目录存在
    if not os.path.exists(SESSION_FILE_DIR):
        os.makedirs(SESSION_FILE_DIR, exist_ok=True)
