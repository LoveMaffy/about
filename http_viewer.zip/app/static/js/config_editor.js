// 配置编辑器脚本

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', () => {
    // 初始化CodeMirror编辑器
    const editor = CodeMirror.fromTextArea(document.getElementById('yamlContent'), {
        mode: 'yaml',
        theme: 'dracula',
        lineNumbers: true,
        lineWrapping: true,
        tabSize: 2,
        indentUnit: 2,
        autoCloseBrackets: true,
        matchBrackets: true,
        highlightSelectionMatches: { showToken: /\w/ }
    });

    // 编辑器状态更新
    editor.on('change', () => {
        document.getElementById('editor-status').textContent = '已修改';
    });

    // 格式化YAML
    document.getElementById('btn-format').addEventListener('click', () => {
        try {
            const yaml = editor.getValue();
            const obj = jsyaml.load(yaml);
            const formattedYaml = jsyaml.dump(obj, { indent: 2, noArrayIndent: true });
            editor.setValue(formattedYaml);
            document.getElementById('editor-status').textContent = '已格式化';
            showMessage('success', '配置已成功格式化');
        } catch (error) {
            showMessage('error', '格式化失败：' + error.message);
        }
    });

    // 验证YAML语法
    document.getElementById('btn-validate').addEventListener('click', () => {
        try {
            const yaml = editor.getValue();
            jsyaml.load(yaml);
            document.getElementById('editor-status').textContent = '语法正确';
            showMessage('success', '配置语法正确');
        } catch (error) {
            document.getElementById('editor-status').textContent = '语法错误';
            showMessage('error', '语法错误：' + error.message);
        }
    });

    // 加载示例配置
    document.getElementById('btn-example').addEventListener('click', () => {
        const exampleYaml = `app:
  name: HTTP Viewer
  version: 1.0.0
  debug: false

database:
  dir: ./data
  default: main.db

log_clean:
  enabled: true
  max_records: 1000
  max_days: 30

server:
  host: 0.0.0.0
  port: 8080
  timeout: 60s`;

        editor.setValue(exampleYaml);
        document.getElementById('editor-status').textContent = '已加载示例配置';
    });

    // 重置配置
    document.getElementById('btn-reset').addEventListener('click', () => {
        if (confirm('确定要重置为默认配置吗？所有修改将丢失')) {
            const defaultYaml = `app:
  name: HTTP Viewer
  version: 1.0.0
  debug: false

database:
  dir: ./data
  default: main.db

log_clean:
  enabled: true
  max_records: 1000
  max_days: 30`;

            editor.setValue(defaultYaml);
            document.getElementById('editor-status').textContent = '已重置为默认配置';
        }
    });

    // 表单提交处理
    document.getElementById('configForm').addEventListener('submit', function(event) {
        event.preventDefault();

        // 显示加载状态
        const submitBtn = this.querySelector('button[type="submit"]');
        const loader = submitBtn.querySelector('.loader');
        submitBtn.disabled = true;
        loader.style.display = 'inline-block';

        // 获取表单数据
        const yamlContent = editor.getValue();

        // 发送AJAX请求保存配置
        fetch('/config/save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ yaml_content: yamlContent })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage('success', '配置文件已成功保存！');
                document.getElementById('editor-status').textContent = '已保存';
            } else {
                showMessage('error', data.error || '保存配置失败');
            }
        })
        .catch(error => {
            showMessage('error', '网络错误：' + error.message);
        })
        .finally(() => {
            // 恢复按钮状态
            submitBtn.disabled = false;
            loader.style.display = 'none';
        });
    });

    // 取消按钮
    document.getElementById('btn-cancel').addEventListener('click', () => {
        if (confirm('确定要取消吗？所有修改将丢失')) {
            // 这里应该刷新页面或重置编辑器内容
            location.reload();
        }
    });

    // 键盘快捷键
    editor.addKeyMap({
        'Ctrl-S': () => document.querySelector('button[type="submit"]').click(),
        'Cmd-S': () => document.querySelector('button[type="submit"]').click(),
        'Ctrl-Alt-F': () => document.getElementById('btn-format').click()
    });
});

// 显示消息函数
function showMessage(type, message) {
    const successEl = document.getElementById('successMessage');
    const errorEl = document.getElementById('errorMessage');
    const errorDetailsEl = document.getElementById('errorDetails');

    // 隐藏所有消息
    successEl.classList.remove('show');
    errorEl.classList.remove('show');

    // 显示对应消息
    if (type === 'success') {
        successEl.querySelector('span').textContent = message;
        successEl.classList.add('show');

        // 3秒后自动隐藏
        setTimeout(() => {
            successEl.classList.remove('show');
        }, 3000);
    } else if (type === 'error') {
        errorDetailsEl.textContent = message;
        errorEl.classList.add('show');
    }
}