/**
 * HTTP Viewer - 主JavaScript文件
 * 提供界面交互、表单验证、数据处理等功能
 */

// DOM加载完成后执行
 document.addEventListener('DOMContentLoaded', function() {
    // 初始化所有功能
    initCopyButtons();
    initFormValidation();
    initTabNavigation();
    initPagination();
    initResponsiveNavigation();
    initTooltips();
    initTableInteractions();
    
    // 检查是否有通知消息，如果有则显示并设置自动隐藏
    initNotifications();
});

/**
 * 初始化复制按钮功能
 */
function initCopyButtons() {
    // 查找所有复制按钮
    const copyButtons = document.querySelectorAll('.btn-copy');
    
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            // 获取要复制的文本
            const targetId = this.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const textToCopy = targetElement.textContent || targetElement.value;
                
                // 使用Clipboard API复制文本
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // 显示复制成功提示
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="bi bi-check"></i> 已复制';
                    this.classList.add('btn-success');
                    this.classList.remove('btn-outline-secondary');
                    
                    // 2秒后恢复原按钮状态
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.classList.remove('btn-success');
                        this.classList.add('btn-outline-secondary');
                    }, 2000);
                }).catch(err => {
                    console.error('复制失败:', err);
                    alert('复制失败，请手动复制');
                });
            }
        });
    });
    
    if (copyButtons.length === 0) {
        console.log('未找到复制按钮');
    }
}

/**
 * 初始化表单验证
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            // 进行基本验证
            const inputs = this.querySelectorAll('input[required], select[required], textarea[required]');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');
                    
                    // 添加错误提示
                    let errorElement = input.nextElementSibling;
                    if (!errorElement || !errorElement.classList.contains('invalid-feedback')) {
                        errorElement = document.createElement('div');
                        errorElement.className = 'invalid-feedback';
                        errorElement.textContent = '此字段为必填项';
                        input.parentNode.appendChild(errorElement);
                    }
                } else {
                    input.classList.remove('is-invalid');
                    input.classList.add('is-valid');
                    
                    // 移除错误提示
                    let errorElement = input.nextElementSibling;
                    if (errorElement && errorElement.classList.contains('invalid-feedback')) {
                        errorElement.remove();
                    }
                }
            });
            
            // 如果验证失败，阻止表单提交
            if (!isValid) {
                event.preventDefault();
                event.stopPropagation();
                this.classList.add('was-validated');
            }
        });
        
        // 输入时移除错误状态
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
                
                let errorElement = this.nextElementSibling;
                if (errorElement && errorElement.classList.contains('invalid-feedback')) {
                    errorElement.remove();
                }
            });
        });
    });
}

/**
 * 初始化标签页导航
 */
function initTabNavigation() {
    const tabLinks = document.querySelectorAll('.nav-tabs .nav-link');
    
    tabLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            // 获取目标标签页ID
            const targetId = this.getAttribute('href');
            
            // 平滑滚动到标签页内容
            if (targetId && targetId.startsWith('#')) {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    // 延迟滚动以确保标签页切换完成
                    setTimeout(() => {
                        targetElement.scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'start' 
                        });
                    }, 100);
                }
            }
        });
    });
}

/**
 * 初始化分页功能 - 实现页码跳转逻辑和加载状态提示
 */
function initPagination() {
    // 为分页容器添加点击事件监听
    const paginationContainer = document.querySelector('.pagination');
    if (paginationContainer) {
        // 添加调试输出
        console.log('分页容器已找到，正在设置事件监听');
        
        // 直接为每个分页链接添加事件监听，而不是使用事件委托
        const pageLinks = paginationContainer.querySelectorAll('a.page-link');
        console.log('找到的分页链接数量:', pageLinks.length);
        
        pageLinks.forEach(link => {
            link.addEventListener('click', function(event) {
                event.preventDefault(); // 阻止默认行为
                event.stopPropagation(); // 阻止事件冒泡
                
                const target = this;
                console.log('点击了分页链接:', target.textContent.trim());
                
                // 检查是否点击了有效的分页链接且未禁用
                if (!target.parentElement.classList.contains('disabled')) {
                    // 显示加载状态指示器
                    showLoadingIndicator();
                    
                    // 获取当前页面信息
                    const currentPageElement = document.querySelector('.text-secondary');
                    let currentPage = 1;
                    let totalPages = 1;
                    
                    if (currentPageElement) {
                        const pageInfo = currentPageElement.textContent;
                        const pageMatch = pageInfo.match(/第\s*(\d+)\s*\/\s*(\d+)\s*页/);
                        if (pageMatch) {
                            currentPage = parseInt(pageMatch[1]) || 1;
                            totalPages = parseInt(pageMatch[2]) || 1;
                        }
                    }
                    
                    // 处理不同类型的分页按钮
                    const textContent = target.textContent.trim();
                    
                    if (textContent === '首页' || textContent === '<<' || target.innerHTML.includes('首页')) {
                        // 首页
                        console.log('点击了首页按钮');
                        navigateToPage(1);
                    } else if (textContent === '上一页' || textContent === '<' || target.innerHTML.includes('&laquo;')) {
                        // 上一页
                        console.log('点击了上一页按钮');
                        navigateToPage(Math.max(1, currentPage - 1));
                    } else if (textContent === '下一页' || textContent === '>' || target.innerHTML.includes('&raquo;') && !target.innerHTML.includes('&raquo;&raquo;')) {
                        // 下一页
                        console.log('点击了下一页按钮');
                        navigateToPage(Math.min(totalPages, currentPage + 1));
                    } else if (textContent === '末页' || textContent === '>>' || target.innerHTML.includes('&raquo;&raquo;')) {
                        // 末页
                        console.log('点击了末页按钮');
                        navigateToPage(totalPages);
                    } else {
                        // 数字页码
                        const pageNum = parseInt(textContent);
                        if (!isNaN(pageNum)) {
                            console.log('数字页码被点击，准备跳转到:', pageNum);
                            navigateToPage(pageNum);
                        }
                    }
                }
            });
        });
    }
    
    // 为页码跳转按钮添加事件监听 - 优化实现确保DOM加载完成
    function setupGotoButton() {
        const gotoButton = document.getElementById('gotoButton');
        const gotoPageInput = document.getElementById('gotoPageInput');
        
        console.log('尝试获取页码跳转按钮元素:', gotoButton ? '已找到' : '未找到');
        console.log('尝试获取页码输入框元素:', gotoPageInput ? '已找到' : '未找到');
        
        if (gotoButton && gotoPageInput) {
            console.log('页码跳转元素已找到，正在设置事件监听');
            
            // 移除任何可能存在的旧事件监听器
            const newGotoButton = gotoButton.cloneNode(true);
            gotoButton.parentNode.replaceChild(newGotoButton, gotoButton);
            
            const newGotoPageInput = gotoPageInput.cloneNode(true);
            gotoPageInput.parentNode.replaceChild(newGotoPageInput, gotoPageInput);
            
            // 重新获取引用
            const updatedGotoButton = document.getElementById('gotoButton');
            const updatedGotoPageInput = document.getElementById('gotoPageInput');
            
            updatedGotoButton.addEventListener('click', function() {
                console.log('跳转按钮被点击！');
                const pageNum = parseInt(updatedGotoPageInput.value);
                const maxPage = parseInt(updatedGotoPageInput.max);
                
                console.log('页码输入值:', updatedGotoPageInput.value);
                console.log('转换后的页码:', pageNum);
                console.log('最大允许页码:', maxPage);
                
                if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= maxPage) {
                    console.log('验证通过，准备跳转到页码:', pageNum);
                    showLoadingIndicator();
                    navigateToPage(pageNum);
                } else {
                    console.log('无效的页码输入:', pageNum);
                    alert('请输入有效页码（1-' + maxPage + '）');
                }
            });
            
            // 添加回车键跳转
            updatedGotoPageInput.addEventListener('keypress', function(event) {
                console.log('在页码输入框中按下了键:', event.key);
                if (event.key === 'Enter') {
                    console.log('按下了回车键，触发按钮点击');
                    event.preventDefault();
                    updatedGotoButton.click();
                }
            });
        }
    }
    
    // 确保在DOM完全加载后设置事件监听器
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupGotoButton);
    } else {
        // DOM已经加载完成，立即执行
        setupGotoButton();
    }
}

/**
 * 导航到指定页码
 * @param {number} pageNum - 目标页码
 */
function navigateToPage(pageNum) {
    // 添加调试输出
    console.log('准备导航到页码:', pageNum);
    
    // 创建URLSearchParams对象并设置页码参数
    const params = new URLSearchParams(window.location.search);
    console.log('当前URL参数:', params.toString());
    
    // 保留现有的page_size参数，只更新page参数
    params.set('page', pageNum);
    
    const newUrl = window.location.pathname + '?' + params.toString();
    console.log('新的URL:', newUrl);
    
    // 跳转到新URL
    window.location.href = newUrl;
}

/**
 * 显示加载状态指示器
 */
function showLoadingIndicator() {
    let loadingIndicator = document.querySelector('.loading-indicator');
    if (!loadingIndicator) {
        loadingIndicator = document.createElement('span');
        loadingIndicator.className = 'loading-indicator';
        loadingIndicator.textContent = '加载中...';
        loadingIndicator.style.position = 'fixed';
        loadingIndicator.style.top = '20px';
        loadingIndicator.style.right = '20px';
        loadingIndicator.style.backgroundColor = '#3498db';
        loadingIndicator.style.color = 'white';
        loadingIndicator.style.padding = '5px 10px';
        loadingIndicator.style.borderRadius = '4px';
        loadingIndicator.style.zIndex = '9999';
        loadingIndicator.style.fontSize = '12px';
        document.body.appendChild(loadingIndicator);
    }
    
    loadingIndicator.style.display = 'block';
    
    // 2秒后隐藏指示器
    setTimeout(() => {
        if (loadingIndicator) {
            loadingIndicator.style.display = 'none';
        }
    }, 2000);
}

/**
 * 初始化响应式导航栏
 */
function initResponsiveNavigation() {
    const navbarTogglers = document.querySelectorAll('.navbar-toggler');
    
    navbarTogglers.forEach(toggler => {
        toggler.addEventListener('click', function() {
            // 获取目标菜单
            const targetId = this.getAttribute('data-target');
            const targetMenu = document.querySelector(targetId);
            
            if (targetMenu) {
                // 添加动画效果
                if (targetMenu.classList.contains('show')) {
                    // 关闭时的动画
                    targetMenu.style.height = targetMenu.offsetHeight + 'px';
                    setTimeout(() => {
                        targetMenu.style.height = '0';
                        setTimeout(() => {
                            targetMenu.classList.remove('show');
                            targetMenu.style.height = '';
                        }, 300);
                    }, 10);
                } else {
                    // 打开时的动画
                    targetMenu.classList.add('show');
                    targetMenu.style.height = '0';
                    setTimeout(() => {
                        targetMenu.style.height = targetMenu.scrollHeight + 'px';
                        setTimeout(() => {
                            targetMenu.style.height = '';
                        }, 300);
                    }, 10);
                }
            }
        });
    });
    
    // 监听窗口大小变化，自动关闭移动菜单
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 992) { // Bootstrap lg断点
            const openMenus = document.querySelectorAll('.navbar-collapse.show');
            openMenus.forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });
}

/**
 * 初始化工具提示
 */
function initTooltips() {
    // 检查浏览器是否支持Bootstrap的Tooltip组件
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipElements = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltipElements.forEach(element => {
            new bootstrap.Tooltip(element);
        });
    }
}

/**
 * 初始化表格交互
 */
function initTableInteractions() {
    const tables = document.querySelectorAll('.table-hover');
    
    tables.forEach(table => {
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            // 添加悬停效果增强
            row.addEventListener('mouseenter', function() {
                this.style.transition = 'all 0.2s ease';
            });
            
            // 如果行有链接，则添加点击跳转功能
            const linkCell = row.querySelector('a[data-row-link]');
            if (linkCell) {
                const href = linkCell.getAttribute('href');
                if (href) {
                    // 为整行添加点击事件，但不影响行内按钮操作
                    row.style.cursor = 'pointer';
                    
                    row.addEventListener('click', function(event) {
                        // 如果点击的是按钮或其内部元素，则不触发行跳转
                        if (!event.target.closest('button')) {
                            window.location.href = href;
                        }
                    });
                }
            }
        });
    });
}

/**
 * 初始化通知消息
 */
function initNotifications() {
    const notifications = document.querySelectorAll('.alert');
    
    notifications.forEach(notification => {
        // 添加淡入动画
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s ease';
        
        setTimeout(() => {
            notification.style.opacity = '1';
        }, 100);
        
        // 设置自动隐藏（除非用户悬停）
        let hideTimeout = setTimeout(() => {
            fadeOutAndRemove(notification);
        }, 5000); // 5秒后自动隐藏
        
        // 用户悬停时暂停自动隐藏
        notification.addEventListener('mouseenter', function() {
            clearTimeout(hideTimeout);
        });
        
        // 用户离开时重新开始计时
        notification.addEventListener('mouseleave', function() {
            hideTimeout = setTimeout(() => {
                fadeOutAndRemove(notification);
            }, 5000);
        });
        
        // 添加关闭按钮功能
        const closeButton = notification.querySelector('.btn-close');
        if (closeButton) {
            closeButton.addEventListener('click', function() {
                fadeOutAndRemove(notification);
            });
        }
    });
}

/**
 * 淡出并移除元素
 */
function fadeOutAndRemove(element) {
    element.style.opacity = '0';
    element.style.transition = 'opacity 0.3s ease, height 0.3s ease 0.3s, margin 0.3s ease 0.3s, padding 0.3s ease 0.3s';
    element.style.height = element.offsetHeight + 'px';
    
    // 强制重绘
    void element.offsetWidth;
    
    // 设置最终状态
    element.style.height = '0';
    element.style.margin = '0';
    element.style.padding = '0';
    element.style.overflow = 'hidden';
    
    // 完全移除元素
    setTimeout(() => {
        element.remove();
    }, 600);
}

/**
 * 搜索表单交互增强
 */
function enhanceSearchForm() {
    const searchForm = document.getElementById('search-form');
    if (!searchForm) return;
    
    // 添加高级搜索切换
    const advancedSearchToggle = searchForm.querySelector('.advanced-search-toggle');
    const advancedSearchFields = searchForm.querySelector('.advanced-search-fields');
    
    if (advancedSearchToggle && advancedSearchFields) {
        advancedSearchToggle.addEventListener('click', function() {
            advancedSearchFields.classList.toggle('d-none');
            
            // 切换图标和文本
            const icon = this.querySelector('i');
            if (icon) {
                if (advancedSearchFields.classList.contains('d-none')) {
                    icon.classList.remove('bi-chevron-up');
                    icon.classList.add('bi-chevron-down');
                    this.innerHTML = '<i class="bi bi-chevron-down"></i> 高级搜索';
                } else {
                    icon.classList.remove('bi-chevron-down');
                    icon.classList.add('bi-chevron-up');
                    this.innerHTML = '<i class="bi bi-chevron-up"></i> 收起';
                }
            }
        });
    }
    
    // 添加输入实时反馈
    const searchInputs = searchForm.querySelectorAll('input, select');
    searchInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    });
}

/**
 * 动态计算文本大小，确保内容适应容器
 */
function fitTextToContainer(element, maxSize = 24, minSize = 12) {
    if (!element) return;
    
    let fontSize = maxSize;
    element.style.fontSize = fontSize + 'px';
    
    while (element.scrollWidth > element.clientWidth && fontSize > minSize) {
        fontSize--;
        element.style.fontSize = fontSize + 'px';
    }
}

/**
 * 为长内容添加截断和展开功能
 */
function initContentTruncation() {
    const truncateElements = document.querySelectorAll('.content-truncate');
    
    truncateElements.forEach(element => {
        // 检查内容是否超出指定行数
        const lineHeight = parseInt(getComputedStyle(element).lineHeight, 10);
        const maxHeight = lineHeight * (element.getAttribute('data-lines') || 3);
        
        if (element.scrollHeight > maxHeight) {
            element.style.maxHeight = maxHeight + 'px';
            element.style.overflow = 'hidden';
            
            // 创建展开按钮
            const expandButton = document.createElement('button');
            expandButton.className = 'btn btn-link p-0 text-primary';
            expandButton.textContent = '展开';
            expandButton.addEventListener('click', function() {
                if (element.style.maxHeight === maxHeight + 'px') {
                    // 展开内容
                    element.style.maxHeight = '';
                    this.textContent = '收起';
                } else {
                    // 收起内容
                    element.style.maxHeight = maxHeight + 'px';
                    this.textContent = '展开';
                }
            });
            
            // 将按钮添加到元素后
            element.parentNode.appendChild(expandButton);
        }
    });
}

/**
 * 防抖函数 - 限制函数在短时间内的调用频率
 */
function debounce(func, wait) {
    let timeout;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), wait);
    };
}

/**
 * 节流函数 - 限制函数在一定时间内只能执行一次
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const context = this;
        const args = arguments;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}
