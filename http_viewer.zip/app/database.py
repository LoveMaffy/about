import sqlite3
from flask import current_app, session, g
import os

def get_db():
    # 从session获取数据库路径，如果没有则使用默认路径
    db_path = session.get('selected_db_path', current_app.config['DEFAULT_DB_PATH'])
    # 添加调试信息，打印当前使用的数据库路径
    print(f"当前使用的数据库路径: {db_path}")
    print(f"session中是否有selected_db_path: {'selected_db_path' in session}")
    print(f"数据库文件是否存在: {os.path.exists(db_path)}")
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn
