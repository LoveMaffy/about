from flask import Blueprint, render_template, request, session, redirect, url_for, flash, jsonify, Response
import yaml
import os
import csv
from io import StringIO
from datetime import datetime, timedelta
import shutil
import math
import logging

from ..database import get_db

main_bp = Blueprint("main", __name__)

# 获取AI配置文件路径
def get_ai_config_path():
    """获取AI配置文件的绝对路径"""
    # 首先尝试在app目录下查找
    ai_config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'AI_config.yaml')
    if os.path.exists(ai_config_path):
        return ai_config_path
    
    # 如果不存在，返回一个默认路径，这样会在保存时创建
    return ai_config_path

@main_bp.route('/ai_config')
def ai_config_editor():
    """显示AI配置编辑器页面"""
    try:
        # 读取AI配置文件内容
        ai_config_path = get_ai_config_path()
        yaml_content = ""
        
        if os.path.exists(ai_config_path):
            with open(ai_config_path, 'r', encoding='utf-8') as f:
                yaml_content = f.read()
        else:
            # 如果文件不存在，提供默认内容
            yaml_content = "# AI配置文件\nai_settings:\n  enabled: true\n  model: \"default\"\n  temperature: 0.7\n"
        
        # 获取数据库表名
        tables = []
        try:
            # 获取数据库连接并获取表名
            db_conn = get_db()
            tables = get_all_tables(db_conn)
        except Exception as e:
            logging.warning(f"获取数据库表名失败: {str(e)}")
            # 如果获取表名失败，不影响页面显示，只是下拉框为空
        
        return render_template('ai_config_editor.html', yaml_content=yaml_content, tables=tables)
    except Exception as e:
        logging.error(f"读取AI配置文件失败: {str(e)}")
        # 如果读取失败，提供一个空的默认内容和空表列表
        return render_template('ai_config_editor.html', yaml_content="# AI配置文件\n", tables=[])

@main_bp.route('/ai_config/save', methods=['POST'])
def save_ai_config():
    """保存AI配置文件"""
    try:
        # 获取请求数据
        data = request.get_json()
        if not data or 'yaml_content' not in data:
            return jsonify({"success": False, "error": "无效的请求数据"})
        
        # 获取YAML内容并验证格式
        yaml_content = data['yaml_content']
        try:
            # 验证YAML格式是否正确
            yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return jsonify({"success": False, "error": f"YAML格式错误: {str(e)}"})
        
        # 保存到文件
        ai_config_path = get_ai_config_path()
        
        # 确保目录存在
        os.makedirs(os.path.dirname(ai_config_path), exist_ok=True)
        
        # 写入文件
        with open(ai_config_path, 'w', encoding='utf-8') as f:
            f.write(yaml_content)
        
        logging.info("AI配置文件保存成功")
        return jsonify({"success": True})
    except Exception as e:
        logging.error(f"保存AI配置文件失败: {str(e)}")
        return jsonify({"success": False, "error": f"保存失败: {str(e)}"})

def get_all_tables(db):
    """
    获取数据库中所有的表名
    """
    tables = []
    try:
        # 查询SQLite数据库中的所有表
        cursor = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [row[0] for row in cursor.fetchall()]
    except Exception as e:
        print(f"获取表列表失败: {e}")
    return tables

def search_records(db, table_name="proxy_records", keyword="", method="", host="", page=1, page_size=20):
    """
    执行数据库查询，根据关键字、method、host进行过滤，并支持分页。
    返回查询结果列表、总记录数和带分页的SQL。
    """
    base_sql = f"SELECT * FROM {table_name} WHERE 1=1"
    count_sql = f"SELECT COUNT(*) FROM {table_name} WHERE 1=1"
    params = []
    
    # 获取表的列信息
    columns = []
    try:
        cursor = db.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]  # row[1]是列名
    except Exception as e:
        print(f"获取表{table_name}的列信息失败: {e}")
    
    # 根据表名和列信息动态构建查询条件
    # 对于系统表如sqlite_sequence，不应用复杂的过滤条件
    if table_name == 'sqlite_sequence' or not columns:
        # 对于系统表，只应用关键字搜索（如果有）
        if keyword:
            # 对于sqlite_sequence表，搜索name列
            if 'name' in columns:
                base_sql += " AND name LIKE ?"
                count_sql += " AND name LIKE ?"
                params.append(f"%{keyword}%")
    else:
        # 对于普通表（如proxy_records），应用所有过滤条件
        # 关键字搜索 (request/response/AI)
        if keyword:
            # 构建动态搜索条件，只包含表中存在的列
            search_columns = []
            search_params = []
            
            # 检查哪些搜索列存在于表中
            possible_search_columns = ['request', 'requestData', 'response', 'responseData', 'ai_sort', 'ai_reason', 'host', 'method', 'url']
            for col in possible_search_columns:
                if col in columns:
                    search_columns.append(f"{col} LIKE ?")
                    search_params.append(f"%{keyword}%")
            
            # 如果有可搜索的列，添加OR条件
            if search_columns:
                base_sql += " AND (" + " OR ".join(search_columns) + ")"
                count_sql += " AND (" + " OR ".join(search_columns) + ")"
                params.extend(search_params)
        
        # HTTP 方法过滤（如果字段存在）
        if method and 'method' in columns:
            base_sql += " AND method = ?"
            count_sql += " AND method = ?"
            params.append(method)
        
        # Host 过滤（如果字段存在）
        if host and 'host' in columns:
            base_sql += " AND host LIKE ?"
            count_sql += " AND host LIKE ?"
            params.append(f"%{host}%")
    
    # 添加排序
    if table_name == 'sqlite_sequence' and columns:
        # 对于sqlite_sequence表，使用name列排序
        order_column = 'name' if 'name' in columns else columns[0]
        base_sql += f" ORDER BY {order_column} ASC"
    else:
        # 对于其他表，优先使用id列排序
        order_column = 'id' if 'id' in columns else (columns[0] if columns else '1')
        # 对于有id列的表使用降序，否则使用升序
        order_direction = 'DESC' if order_column == 'id' else 'ASC'
        base_sql += f" ORDER BY {order_column} {order_direction}"
    
    # 查询总数
    try:
        total = db.execute(count_sql, params).fetchone()[0]
    except Exception as e:
        print(f"查询总数失败: {e}")
        # 如果查询失败，尝试不使用过滤条件重新查询
        try:
            total = db.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
        except:
            total = 0
    
    # 计算总页数
    total_pages = math.ceil(total / page_size) if page_size > 0 else 1
    
    # 添加分页
    if page_size > 0:
        offset = (page - 1) * page_size
        base_sql += f" LIMIT {page_size} OFFSET {offset}"
    
    return base_sql, params, total, total_pages

@main_bp.route("/")
def index():
    # 检查用户是否已选择数据库
    if 'selected_db_path' not in session:
        # 如果没有选择数据库，重定向到数据库选择页面
        return redirect(url_for("db_selector.select_database"))
    
    # 获取查询参数
    keyword = request.args.get("q", "").strip()
    method = request.args.get("method", "").strip().upper()
    host = request.args.get("host", "").strip()
    # 获取当前选择的表名，默认为proxy_records
    table_name = request.args.get("table", "proxy_records").strip()
    
    # 分页参数
    try:
        page = int(request.args.get("page", 1))
        page = max(1, page)  # 确保页码不小于1
    except ValueError:
        page = 1
    
    try:
        page_size = int(request.args.get("page_size", 20))
        # 限制页大小范围
        page_size = min(max(1, page_size), 1000)
    except ValueError:
        page_size = 20

    db = get_db()
    
    # 获取所有表名
    tables = get_all_tables(db)
    
    # 确保选择的表名有效
    if not tables or table_name not in tables:
        table_name = tables[0] if tables else "proxy_records"

    # 调用搜索函数，添加分页参数
    base_sql, params, total, total_pages = search_records(
        db, table_name, keyword, method, host, page, page_size
    )
    
    # 执行查询
    rows = db.execute(base_sql, params).fetchall()
    
    # 确保页码不超过总页数
    page = min(page, total_pages)

    return render_template(
        "index.html",
        rows=rows,
        current_page=page,
        total_pages=total_pages,
        total_records=total,
        page_size=page_size,
        keyword=keyword,
        method=method,
        host=host,
        tables=tables,
        current_table=table_name
    )

@main_bp.route("/log_clean")
def log_clean():
    # 检查session中是否存在selected_db_path
    if 'selected_db_path' not in session:
        return redirect(url_for('database_selector.database_selector'))
    
    # 获取table参数，如果没有则默认为'proxy_records'
    table = request.args.get('table', 'proxy_records')
    table_name = request.args.get("table", "proxy_records").strip()    # 获取数据库连接
    db = get_db()
    
    # 获取所有表
    tables = get_all_tables(db)
    
    # 验证表名是否有效
    if table not in tables:
        table = 'proxy_records'
    
    # 渲染log_clean.html模板
    return render_template('log_clean.html', table=table, tables=tables)


@main_bp.route("/config_editor")
def config_editor():
    """显示配置编辑器页面，读取config.yaml文件内容"""
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config.yaml')
    db = get_db()
    # 获取所有表
    tables = get_all_tables(db)
    table_name = request.args.get("table", "proxy_records").strip()  # 获取数据库连接
    try:
        # 读取config.yaml文件内容
        with open(config_path, 'r', encoding='utf-8') as file:
            yaml_content = file.read()
        
        # 渲染配置编辑器页面
        return render_template('config_editor.html', yaml_content=yaml_content,tables=tables,current_table=table_name)
    except Exception as e:
        flash(f"读取配置文件时出错: {str(e)}", 'error')
        return render_template('config_editor.html', yaml_content='',tables=tables,current_table=table_name)


@main_bp.route("/config/save", methods=['POST'])
def save_config():
    """保存配置文件"""
    try:
        # 获取请求数据
        data = request.get_json()
        yaml_content = data.get('yaml_content', '')
        
        # 验证YAML格式是否有效
        try:
            yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return jsonify({'success': False, 'error': f'无效的YAML格式: {str(e)}'})
        
        # 保存到config.yaml文件
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config.yaml')
        with open(config_path, 'w', encoding='utf-8') as file:
            file.write(yaml_content)
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': f'保存配置文件时出错: {str(e)}'})

@main_bp.route("/export_csv")
def export_csv():
    """导出表数据为CSV文件"""
    try:
        # 检查用户是否已选择数据库
        if 'selected_db_path' not in session:
            return redirect(url_for("db_selector.select_database"))
        
        # 获取查询参数
        keyword = request.args.get("q", "").strip()
        method = request.args.get("method", "").strip().upper()
        host = request.args.get("host", "").strip()
        # 获取当前选择的表名，默认为proxy_records
        table_name = request.args.get("table", "proxy_records").strip()
        
        db = get_db()
        
        # 验证表名
        tables = get_all_tables(db)
        if not tables or table_name not in tables:
            flash(f"无效的表名: {table_name}", 'error')
            return redirect(url_for('main.index'))
        
        # 构建查询SQL（不分页，获取所有记录）
        base_sql, params, _, _ = search_records(
            db, table_name, keyword, method, host, page=1, page_size=0  # page_size=0表示不分页
        )
        
        # 移除分页限制
        if "LIMIT" in base_sql.upper() and "OFFSET" in base_sql.upper():
            # 移除LIMIT和OFFSET部分
            parts = base_sql.split("LIMIT")
            base_sql = parts[0].strip()
        
        # 执行查询获取所有记录
        cursor = db.execute(base_sql, params)
        rows = cursor.fetchall()
        
        # 获取列名
        columns = [desc[0] for desc in cursor.description]
        
        # 创建CSV内容
        output = StringIO()
        writer = csv.writer(output)
        
        # 写入表头
        writer.writerow(columns)
        
        # 写入数据行
        for row in rows:
            # 处理row对象，确保所有值都能被正确转换为字符串
            row_values = []
            for value in row:
                if value is None:
                    row_values.append('')
                else:
                    # 确保值是字符串类型
                    try:
                        row_values.append(str(value))
                    except:
                        row_values.append('')
            writer.writerow(row_values)
        
        # 设置响应头
        filename = f"{table_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        response = Response(output.getvalue(), mimetype='text/csv')
        response.headers.set("Content-Disposition", f"attachment; filename={filename}")
        
        return response
        
    except Exception as e:
        logging.error(f"导出CSV失败: {str(e)}")
        flash(f"导出CSV失败: {str(e)}", 'error')
        return redirect(url_for('main.index'))

@main_bp.route("/log_clean/execute", methods=["POST"])
def execute_log_clean():
    try:
        if 'selected_db_path' not in session:
            return jsonify({"success": False, "message": "请先选择数据库"})
        
        # 获取请求数据
        data = request.get_json()
        clean_type = data.get('clean_type', 'records')
        count = data.get('count', 5000)
        backup = data.get('backup', False)
        
        # 读取YAML配置
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config.yaml')
        config = {}
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
        except Exception as e:
            print(f"读取配置文件失败: {e}")
        
        # 获取当前数据库
        db_path = session['selected_db_path']
        db = get_db()
        table_name = request.args.get("table", "proxy_records").strip()
        
        # 备份数据
        if backup:
            try:
                # 创建备份目录
                backup_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'db_log_backup')
                os.makedirs(backup_dir, exist_ok=True)
                
                # 生成备份文件名
                backup_time = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_folder = os.path.join(backup_dir, f"backup_{backup_time}")
                os.makedirs(backup_folder, exist_ok=True)
                
                # 复制数据库文件
                backup_file = os.path.join(backup_folder, os.path.basename(db_path))
                shutil.copy2(db_path, backup_file)
                print(f"数据库已备份至: {backup_file}")
            except Exception as e:
                print(f"备份失败: {e}")
                return jsonify({"success": False, "message": f"备份失败: {str(e)}"})
        
        # 执行清理操作
        deleted_count = 0
        with db:
            cursor = db.cursor()
            
            if clean_type == 'records':
                # 按记录数量清理
                # 首先获取要保留的记录的最小ID
                cursor.execute(f"SELECT MIN(id) FROM (SELECT id FROM {table_name} ORDER BY id DESC LIMIT ?)", (count,))
                result = cursor.fetchone()
                if result and result[0]:
                    min_id_to_keep = result[0]
                    # 删除早于最小保留ID的记录
                    cursor.execute(f"DELETE FROM {table_name} WHERE id < ?", (min_id_to_keep,))
                    deleted_count = cursor.rowcount
                    print(f"按记录数清理: 删除了 {deleted_count} 条记录")
            else:
                # 按天数清理
                # 计算截止日期
                cutoff_date = datetime.now() - timedelta(days=count)
                # 删除早于截止日期的记录
                cursor.execute(f"DELETE FROM {table_name} WHERE time < ?", (cutoff_date.strftime('%Y-%m-%d %H:%M:%S'),))
                deleted_count = cursor.rowcount
                print(f"按天数清理: 删除了 {deleted_count} 条记录")
            
            # 提交事务
            db.commit()
        
        return jsonify({
            "success": True,
            "message": f"日志清理成功！删除了 {deleted_count} 条记录",
            "stats": {"deleted_count": deleted_count}
        })
        
    except Exception as e:
        print(f"清理日志时出错: {e}")
        return jsonify({"success": False, "message": f"清理失败: {str(e)}"})

