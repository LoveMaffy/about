from flask import Blueprint, render_template, request, session, redirect, url_for, flash, jsonify


from ..database import get_db
import math
import sqlite3
import json

main_bp = Blueprint("main", __name__)

def get_all_tables(db):
    """
    获取数据库中所有的表名
    """
    tables = []
    try:
        # 查询SQLite数据库中的所有表
        cursor = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [row[0] for row in cursor.fetchall()]
    except Exception as e:
        print(f"获取表列表失败: {e}")
    return tables

def search_records(db, table_name="proxy_records", keyword="", method="", host="", page=1, page_size=20):
    """
    执行数据库查询，根据关键字、method、host进行过滤，并支持分页。
    返回查询结果列表、总记录数和带分页的SQL。
    """
    base_sql = f"SELECT * FROM {table_name} WHERE 1=1"
    count_sql = f"SELECT COUNT(*) FROM {table_name} WHERE 1=1"
    params = []
    
    # 获取表的列信息
    columns = []
    try:
        cursor = db.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]  # row[1]是列名
    except Exception as e:
        print(f"获取表{table_name}的列信息失败: {e}")
    
    # 根据表名和列信息动态构建查询条件
    # 对于系统表如sqlite_sequence，不应用复杂的过滤条件
    if table_name == 'sqlite_sequence' or not columns:
        # 对于系统表，只应用关键字搜索（如果有）
        if keyword:
            # 对于sqlite_sequence表，搜索name列
            if 'name' in columns:
                base_sql += " AND name LIKE ?"
                count_sql += " AND name LIKE ?"
                params.append(f"%{keyword}%")
    else:
        # 对于普通表（如proxy_records），应用所有过滤条件
        # 关键字搜索 (request/response/AI)
        if keyword:
            # 构建动态搜索条件，只包含表中存在的列
            search_columns = []
            search_params = []
            
            # 检查哪些搜索列存在于表中
            possible_search_columns = ['request', 'requestData', 'response', 'responseData', 'ai_sort', 'ai_reason', 'host', 'method', 'url']
            for col in possible_search_columns:
                if col in columns:
                    search_columns.append(f"{col} LIKE ?")
                    search_params.append(f"%{keyword}%")
            
            # 如果有可搜索的列，添加OR条件
            if search_columns:
                base_sql += " AND (" + " OR ".join(search_columns) + ")"
                count_sql += " AND (" + " OR ".join(search_columns) + ")"
                params.extend(search_params)
        
        # HTTP 方法过滤（如果字段存在）
        if method and 'method' in columns:
            base_sql += " AND method = ?"
            count_sql += " AND method = ?"
            params.append(method)
        
        # Host 过滤（如果字段存在）
        if host and 'host' in columns:
            base_sql += " AND host LIKE ?"
            count_sql += " AND host LIKE ?"
            params.append(f"%{host}%")
    
    # 添加排序
    if table_name == 'sqlite_sequence' and columns:
        # 对于sqlite_sequence表，使用name列排序
        order_column = 'name' if 'name' in columns else columns[0]
        base_sql += f" ORDER BY {order_column} ASC"
    else:
        # 对于其他表，优先使用id列排序
        order_column = 'id' if 'id' in columns else (columns[0] if columns else '1')
        # 对于有id列的表使用降序，否则使用升序
        order_direction = 'DESC' if order_column == 'id' else 'ASC'
        base_sql += f" ORDER BY {order_column} {order_direction}"
    
    # 查询总数
    try:
        total = db.execute(count_sql, params).fetchone()[0]
    except Exception as e:
        print(f"查询总数失败: {e}")
        # 如果查询失败，尝试不使用过滤条件重新查询
        try:
            total = db.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
        except:
            total = 0
    
    # 计算总页数
    total_pages = math.ceil(total / page_size) if page_size > 0 else 1
    
    # 添加分页
    if page_size > 0:
        offset = (page - 1) * page_size
        base_sql += f" LIMIT {page_size} OFFSET {offset}"
    
    return base_sql, params, total, total_pages
@main_bp.route("/")
def index():
    # 检查用户是否已选择数据库
    if 'selected_db_path' not in session:
        # 如果没有选择数据库，重定向到数据库选择页面
        return redirect(url_for("db_selector.select_database"))
    
    # 获取查询参数
    keyword = request.args.get("q", "").strip()
    method = request.args.get("method", "").strip().upper()
    host = request.args.get("host", "").strip()
    # 获取当前选择的表名，默认为proxy_records
    table_name = request.args.get("table", "proxy_records").strip()
    
    # 分页参数
    try:
        page = int(request.args.get("page", 1))
        page = max(1, page)  # 确保页码不小于1
    except ValueError:
        page = 1
    
    try:
        page_size = int(request.args.get("page_size", 20))
        # 限制页大小范围
        page_size = min(max(1, page_size), 1000)
    except ValueError:
        page_size = 20

    db = get_db()
    
    # 获取所有表名
    tables = get_all_tables(db)
    
    # 确保选择的表名有效
    if not tables or table_name not in tables:
        table_name = tables[0] if tables else "proxy_records"

    # 调用搜索函数，添加分页参数
    base_sql, params, total, total_pages = search_records(
        db, table_name, keyword, method, host, page, page_size
    )
    
    # 执行查询
    rows = db.execute(base_sql, params).fetchall()
    
    # 确保页码不超过总页数
    page = min(page, total_pages)

    return render_template(
        "index.html",
        rows=rows,
        current_page=page,
        total_pages=total_pages,
        total_records=total,
        page_size=page_size,
        keyword=keyword,
        method=method,
        host=host,
        tables=tables,
        current_table=table_name
    )

@main_bp.route('/mark_vulnerability', methods=['POST'])
def mark_vulnerability():
    """标记漏洞"""
    try:
        record_id = request.form.get('record_id')
        is_vulnerable = request.form.get('is_vulnerable', '1')
        note = request.form.get('note', '')
        
        if not record_id:
            return jsonify({'success': False, 'error': '缺少记录ID'})
        
        db = get_db()
        
        # 更新漏洞状态和备注
        db.execute(
            "UPDATE proxy_records SET vulnerability_status = ?, vulnerability_note = ? WHERE id = ?",
            (int(is_vulnerable), note, record_id)
        )
        db.commit()
        
        return jsonify({'success': True, 'message': '漏洞状态已更新'})
    except Exception as e:
        print(f"标记漏洞时出错: {e}")
        return jsonify({'success': False, 'error': str(e)})

# toggle_vulnerability 函数已移除，不再需要漏洞状态切换功能
