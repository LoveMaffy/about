from flask import Blueprint, render_template, request, redirect, url_for
from ..database import get_db
import time

detail_bp = Blueprint("detail", __name__, url_prefix="/detail")

@detail_bp.route("/<int:record_id>/<string:table_name>")
def detail(record_id,table_name):
    db = get_db()
    row = db.execute(
        f"SELECT * FROM {table_name} WHERE id = ?", (record_id,)
    ).fetchone()
    return render_template("detail.html", row=row)



@detail_bp.route("/add", methods=["GET", "POST"])
def add_record():
    if request.method == "POST":
        # 获取表单数据
        method = request.form.get("method", "GET")
        host = request.form.get("host", "")
        request_data = request.form.get("request", "")
        request_body = request.form.get("requestData", "")
        response_data = request.form.get("response", "")
        response_body = request.form.get("responseData", "")
        ai_sort = request.form.get("ai_sort", "")
        ai_reason = request.form.get("ai_reason", "")
        
        # 获取当前时间戳
        current_time = time.time()
        
        # 保存到数据库
        db = get_db()
        try:
            db.execute(
                "INSERT INTO proxy_records (time, method, host, request, requestData, response, responseData, ai_sort, ai_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (current_time, method, host, request_data, request_body, response_data, response_body, ai_sort, ai_reason)
            )
            db.commit()
            return redirect(url_for("main.index"))
        except Exception as e:
            print(f"添加记录失败: {e}")
            db.rollback()
    
    # GET请求时渲染表单
    return render_template("crud_form.html", action="Add", record=None)

@detail_bp.route("/delete/<int:record_id>", methods=["POST"])
def delete_record(record_id):
    db = get_db()
    try:
        # 删除记录
        db.execute("DELETE FROM proxy_records WHERE id = ?", (record_id,))
        db.commit()
    except Exception as e:
        print(f"删除记录失败: {e}")
        db.rollback()
    
    return redirect(url_for("main.index"))

@detail_bp.route("/clone/<int:record_id>", methods=["POST"])
def clone_record(record_id):
    db = get_db()
    try:
        # 获取要克隆的记录
        record = db.execute("SELECT * FROM proxy_records WHERE id = ?", (record_id,)).fetchone()
        if record:
            # 获取当前时间戳作为新记录的时间
            current_time = time.time()
            # 插入新记录，使用原记录的数据但更新时间戳
            db.execute(
                "INSERT INTO proxy_records (time, method, host, request_header, request_body, response_header, response_body, ai_sort, analysis_result) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (current_time, record.method, record.host, record.request_header, record.request_body, 
                 record.response_header, record.response_body, record.ai_sort, record.analysis_result)
            )
            db.commit()
    except Exception as e:
        print(f"克隆记录失败: {e}")
        db.rollback()
    
    return redirect(url_for("main.index"))

@detail_bp.route("/edit/<int:record_id>", methods=["GET", "POST"])
def edit_record(record_id):
    db = get_db()
    
    if request.method == "POST":
        # 获取表单数据
        method = request.form.get("method", "GET")
        host = request.form.get("host", "")
        request_header = request.form.get("request_header", "")
        request_body = request.form.get("request_body", "")
        response_header = request.form.get("response_header", "")
        response_body = request.form.get("response_body", "")
        ai_sort = request.form.get("ai_sort", "")
        analysis_result = request.form.get("analysis_result", "")
        
        # 更新数据库
        try:
            db.execute(
                "UPDATE proxy_records SET method = ?, host = ?, request = ?, requestData = ?, response = ?, responseData = ?, ai_sort = ?, ai_reason = ? WHERE id = ?",
                (method, host, request, requestData, response, responseData, ai_sort, ai_reason, record_id)
            )
            db.commit()
            return redirect(url_for("main.index"))
        except Exception as e:
            print(f"更新记录失败: {e}")
            db.rollback()
    
    # GET请求时获取记录并渲染表单
    record = db.execute(
        "SELECT * FROM proxy_records WHERE id = ?", (record_id,)
    ).fetchone()
    
    if not record:
        return redirect(url_for("main.index"))
    
    return render_template("crud_form.html", action="Edit", record=record)



