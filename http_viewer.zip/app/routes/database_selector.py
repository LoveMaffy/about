from flask import Blueprint, render_template, request, session, redirect, url_for, current_app
import os
from ..config import Config

# 创建数据库选择器蓝图
db_selector_bp = Blueprint("db_selector", __name__)

@db_selector_bp.route("/select", methods=["GET", "POST"])
def select_database():
    # 获取数据库目录路径
    db_dir = Config.DB_DIR
    
    # 调试信息：打印session状态
    print("=== 进入数据库选择页面 ===")
    print(f"session中的selected_db_path: {session.get('selected_db_path')}")
    print(f"数据库目录: {db_dir}")
    print(f"是否存在数据库目录: {os.path.exists(db_dir)}")
    
    # 获取当前选择的数据库文件
    current_db = None
    has_selected_db = 'selected_db_path' in session
    
    if has_selected_db:
        current_db = os.path.basename(session['selected_db_path'])
    else:
        current_db = os.path.basename(Config.DEFAULT_DB_PATH)
    
    if request.method == "POST":
        # 调试信息：打印POST请求数据
        print("=== 处理POST请求 ===")
        print(f"表单数据: {request.form}")
        
        # 获取用户选择的数据库文件
        selected_db = request.form.get("db_file")
        print(f"用户选择的数据库: {selected_db}")
        
        if selected_db:
            # 构建完整的数据库路径
            db_path = os.path.join(db_dir, selected_db)
            print(f"构建的数据库路径: {db_path}")
            
            # 验证文件是否存在
            print(f"数据库文件是否存在: {os.path.exists(db_path)}")
            
            if os.path.exists(db_path):
                # 保存到session
                session['selected_db_path'] = db_path
                print(f"已保存到session: {session.get('selected_db_path')}")
                # 重定向到首页
                return redirect(url_for("main.index"))
            else:
                print("错误: 数据库文件不存在")
        else:
            print("错误: 未选择数据库文件")
    
    # 获取db_log目录中的所有.db文件
    db_files = []
    try:
        # 列出目录中的所有文件
        all_files = os.listdir(db_dir)
        # 过滤出.db文件
        db_files = [f for f in all_files if f.endswith('.db')]
    except Exception as e:
        print(f"读取数据库目录失败: {e}")
    
    return render_template("database_selector.html", db_files=db_files, current_db=current_db, has_selected_db=has_selected_db)
