# HTTP Viewer - 网络安全流量分析工具

## 项目概述
HTTP Viewer是一款基于Python + Flask构建的Web数据库管理工具，专为网络安全分析场景设计。系统主要用于管理和分析HTTP请求/响应数据包，特别适用于网络安全蜜罐数据分析、流量审计和异常检测等场景。通过直观的Web界面，安全研究人员可以高效地检索、过滤和分析大量HTTP流量数据，快速识别潜在威胁和异常行为。

## 技术栈
- **后端框架**：Flask 3.0+
- **数据库**：SQLite
- **前端**：Bootstrap 5.3、HTML5、CSS3
- **会话管理**：Flask-Session
- **开发语言**：Python 3.11+

## ✨ 核心功能

### 1. 数据库管理
- 支持多数据库切换（通过下拉菜单便捷选择）
- 首次访问自动引导数据库选择
- 会话持久化保存用户选择的数据库

### 2. 数据查询与过滤
- **关键词搜索**：全字段模糊搜索（请求头/响应头/请求体/响应体）
- **多维度过滤**：
  - HTTP方法过滤（GET/POST/PUT/DELETE等）
  - Host过滤
  - 分页浏览（每页20条记录）
- **排序功能**：按记录ID降序排列，最新数据优先显示

### 3. 数据展示
- 结构化展示HTTP数据包信息
- 支持查看详细记录
- 优雅的用户界面，响应式设计

### 4. 安全与兼容性
- 会话安全管理
- 文件权限控制
- 良好的错误处理机制

## 项目目录结构
```
h:/work/http_viewer/
├── app/                          # 主应用目录
│   ├── __init__.py               # 应用初始化
│   ├── config.py                 # 配置文件
│   ├── database.py               # 数据库连接管理
│   ├── routes/                   # 路由模块
│   │   ├── main.py               # 主页面路由
│   │   ├── detail.py             # 详情页路由
│   │   └── database_selector.py  # 数据库选择器路由
│   ├── static/                   # 静态资源
│   │   ├── css/                  # 样式文件
│   │   └── js/                   # JavaScript文件
│   └── templates/                # HTML模板
│       ├── base.html             # 基础模板
│       ├── index.html            # 首页
│       ├── detail.html           # 详情页
│       └── database_selector.html # 数据库选择页面
├── db_log/                       # 数据库文件存储目录
│   ├── http.db                   # 默认数据库
│   └── http1.db                  # 示例数据库
├── flask_session/                # 会话文件存储
├── requirements.txt              # 依赖清单
├── run.py                        # 应用入口
└── readme.md                     # 项目文档
```

## 数据库结构（SQLite）

### proxy_records表
| 字段名          | 类型 | 描述                |
|--------------|------|-------------------|
| id           | INTEGER | 数据包唯一标识，自增主键      |
| time         | DATETIME | 捕获时间戳             |
| request      | TEXT | HTTP请求头（JSON格式）   |
| requestData  | TEXT | HTTP请求体（原始内容）     |
| response     | TEXT | HTTP响应头           |
| responseData | TEXT | HTTP响应体           |
| method       | TEXT | HTTP方法（GET/POST等） |
| host         | TEXT | 请求主机              |
| ai_sort      | TEXT | AI自动分类标签（信息泄露）    |
| ai_reason    | TEXT | AI生成的详细分析结果       |



应用将在 http://localhost:5000 启动，可通过浏览器访问。

## 使用指南

### 1. 数据库选择
- 首次访问时，系统会自动引导您选择数据库
- 在右上角可查看当前选择的数据库
- 点击下拉菜单可随时切换到其他数据库文件

### 2. 数据查询
- 在首页可使用搜索框输入关键词进行模糊搜索
- 可通过HTTP方法下拉框过滤特定类型的请求
- 可输入Host进行主机过滤
- 使用分页控件浏览大量数据

### 3. 数据查看
- 点击记录可查看详细信息
- 系统会格式化显示HTTP头和内容

## 配置说明

主要配置位于 `app/config.py` 文件中，可根据需要调整以下参数：

- **数据库配置**：
  - `DB_DIR`：数据库文件存储目录
  - `DEFAULT_DB_PATH`：默认数据库路径

- **会话配置**：
  - `SECRET_KEY`：会话安全密钥
  - `SESSION_TYPE`：会话存储类型（默认filesystem）
  - `SESSION_FILE_DIR`：会话文件存储目录

## 开发说明

### 添加新功能
1. 在 `app/routes/` 目录下创建新的路由模块
2. 在 `app/__init__.py` 中注册新的蓝图
3. 在 `app/templates/` 目录下创建对应的HTML模板

### 调试模式
应用默认以调试模式运行（`debug=True`），便于开发和问题排查。生产环境部署时建议关闭调试模式并配置适当的错误处理。

## 安全注意事项
- 本工具设计用于内部网络安全分析，不建议直接暴露在公网
- 生产环境使用时请修改默认的`SECRET_KEY`
- 确保数据库文件具有适当的访问权限

