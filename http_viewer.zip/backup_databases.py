import os
import shutil
from datetime import datetime

# 数据库文件目录和备份目录
db_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db_log')
backup_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db_log_backup')

def backup_all_databases():
    """备份所有数据库文件"""
    try:
        # 创建备份目录，如果不存在
        os.makedirs(backup_dir, exist_ok=True)
        
        # 添加时间戳到备份目录
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        timestamped_backup_dir = os.path.join(backup_dir, f"backup_{timestamp}")
        os.makedirs(timestamped_backup_dir, exist_ok=True)
        
        print(f"开始备份数据库文件到: {timestamped_backup_dir}")
        
        # 获取所有.db文件
        db_files = [f for f in os.listdir(db_dir) if f.endswith('.db')]
        
        if not db_files:
            print(f"在 {db_dir} 目录中未找到任何.db文件")
            return False
        
        # 备份每个文件
        for db_file in db_files:
            source_path = os.path.join(db_dir, db_file)
            dest_path = os.path.join(timestamped_backup_dir, db_file)
            
            shutil.copy2(source_path, dest_path)
            print(f"  已备份: {db_file} -> {dest_path}")
        
        print(f"\n备份完成！共备份了 {len(db_files)} 个数据库文件")
        print(f"备份文件位置: {timestamped_backup_dir}")
        return True
    except Exception as e:
        print(f"备份过程中出错: {str(e)}")
        return False

if __name__ == "__main__":
    print("===== HTTP Viewer 数据库备份工具 =====")
    backup_all_databases()
