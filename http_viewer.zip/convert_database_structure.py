import sqlite3
import os
import json
from datetime import datetime

# 数据库文件目录
db_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db_log')

def convert_database(db_path):
    """
    将数据库结构转换为README中定义的格式
    
    当前结构:
    - id: INTEGER
    - time: REAL
    - request_header: TEXT
    - request_body: TEXT
    - response_header: TEXT
    - response_body: TEXT
    - ai_sort: TEXT
    - analysis_result: TEXT
    - method: TEXT
    - host: TEXT
    - vulnerability_status: INTEGER
    - vulnerability_note: TEXT
    
    目标结构:
    - id: INTEGER
    - time: DATETIME
    - request: TEXT (HTTP请求头，JSON格式)
    - requestData: TEXT (HTTP请求体)
    - response: TEXT (HTTP响应头)
    - responseData: TEXT (HTTP响应体)
    - method: TEXT
    - host: TEXT
    - ai_sort: TEXT
    - ai_reason: TEXT
    """
    try:
        # 连接数据库
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print(f"正在处理数据库: {db_path}")
        
        # 检查proxy_records表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='proxy_records'")
        if cursor.fetchone() is None:
            print(f"  警告: {os.path.basename(db_path)} 中不存在proxy_records表")
            conn.close()
            return False
        
        # 创建新表，使用README中定义的结构
        print("  创建新的表结构...")
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS proxy_records_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                time DATETIME,
                request TEXT,
                requestData TEXT,
                response TEXT,
                responseData TEXT,
                method TEXT,
                host TEXT,
                ai_sort TEXT,
                ai_reason TEXT
            )
        ''')
        
        # 从旧表复制数据到新表，进行字段映射和类型转换
        print("  复制数据...")
        
        # 获取旧表中的所有数据
        cursor.execute("SELECT * FROM proxy_records")
        rows = cursor.fetchall()
        
        # 获取旧表的列信息
        cursor.execute("PRAGMA table_info(proxy_records)")
        columns_info = cursor.fetchall()
        columns = [col[1] for col in columns_info]
        
        # 准备插入语句
        insert_sql = '''
            INSERT INTO proxy_records_new (
                id, time, request, requestData, response, responseData, 
                method, host, ai_sort, ai_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        '''
        
        # 处理每一行数据
        row_count = 0
        for row in rows:
            # 将行转换为字典便于处理
            row_dict = dict(zip(columns, row))
            
            # 准备插入参数
            # 1. id保持不变
            new_id = row_dict.get('id', None)
            
            # 2. 将REAL类型的time转换为DATETIME字符串
            # SQLite中REAL类型的时间戳通常是Unix时间戳
            time_val = row_dict.get('time', None)
            if time_val is not None:
                try:
                    # 转换Unix时间戳为ISO格式的datetime字符串
                    # 注意：有些系统使用毫秒，有些使用秒，这里尝试两种方式
                    if time_val > 1e12:  # 毫秒
                        time_val = datetime.fromtimestamp(time_val / 1000).isoformat()
                    else:  # 秒
                        time_val = datetime.fromtimestamp(time_val).isoformat()
                except:
                    time_val = str(time_val)  # 转换失败则保持字符串形式
            
            # 3-6. 字段重命名映射
            request = row_dict.get('request_header', '')
            requestData = row_dict.get('request_body', '')
            response = row_dict.get('response_header', '')
            responseData = row_dict.get('response_body', '')
            
            # 7-8. 保持不变的字段
            method = row_dict.get('method', '')
            host = row_dict.get('host', '')
            
            # 9. 保持不变的字段
            ai_sort = row_dict.get('ai_sort', '')
            
            # 10. analysis_result 重命名为 ai_reason
            ai_reason = row_dict.get('analysis_result', '')
            
            # 执行插入
            cursor.execute(insert_sql, (
                new_id, time_val, request, requestData, response, responseData,
                method, host, ai_sort, ai_reason
            ))
            
            row_count += 1
            if row_count % 100 == 0:
                print(f"  已处理 {row_count} 行数据")
        
        print(f"  数据复制完成，共处理 {row_count} 行")
        
        # 重命名表：删除旧表，将新表重命名为原表名
        print("  更新表名...")
        
        # 先重命名旧表，保留备份
        try:
            cursor.execute("ALTER TABLE proxy_records RENAME TO proxy_records_old")
        except sqlite3.OperationalError:
            # 如果已存在旧表，则先删除它
            cursor.execute("DROP TABLE IF EXISTS proxy_records_old")
            cursor.execute("ALTER TABLE proxy_records RENAME TO proxy_records_old")
        
        # 将新表重命名为原表名
        cursor.execute("ALTER TABLE proxy_records_new RENAME TO proxy_records")
        
        # 更新序列计数器，确保自增ID正确
        max_id = cursor.execute("SELECT MAX(id) FROM proxy_records").fetchone()[0]
        if max_id is not None:
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='proxy_records'")
            cursor.execute("INSERT INTO sqlite_sequence (name, seq) VALUES ('proxy_records', ?)", (max_id,))
        
        # 提交更改
        conn.commit()
        print(f"  数据库 {os.path.basename(db_path)} 结构转换完成")
        
        # 关闭连接
        conn.close()
        return True
        
    except Exception as e:
        print(f"  处理数据库 {os.path.basename(db_path)} 时出错: {str(e)}")
        # 出错时回滚
        if 'conn' in locals():
            conn.rollback()
            conn.close()
        return False

def main():
    # 获取db_log目录中的所有.db文件
    db_files = [f for f in os.listdir(db_dir) if f.endswith('.db')]
    
    if not db_files:
        print(f"在 {db_dir} 目录中未找到任何.db文件")
        return
    
    print(f"找到 {len(db_files)} 个数据库文件")
    
    # 转换每个数据库文件
    success_count = 0
    fail_count = 0
    
    for db_file in db_files:
        db_path = os.path.join(db_dir, db_file)
        print(f"\n开始处理: {db_file}")
        
        # 先备份数据库
        backup_path = os.path.join(db_dir, f"{os.path.splitext(db_file)[0]}_backup.db")
        print(f"  正在备份到: {os.path.basename(backup_path)}")
        
        try:
            # 复制文件作为备份
            import shutil
            shutil.copy2(db_path, backup_path)
            print(f"  备份成功")
            
            # 转换数据库
            if convert_database(db_path):
                success_count += 1
            else:
                fail_count += 1
                # 如果转换失败，恢复备份
                print("  转换失败，正在恢复备份...")
                shutil.copy2(backup_path, db_path)
                print("  备份已恢复")
        except Exception as e:
            print(f"  备份或恢复过程中出错: {str(e)}")
            fail_count += 1
    
    # 输出总结
    print(f"\n转换总结:")
    print(f"- 成功: {success_count}")
    print(f"- 失败: {fail_count}")
    print(f"\n注意: 已为每个数据库文件创建备份，文件名格式为: 原文件名_backup.db")
    print("      转换后的数据库结构已更新为README中定义的格式")

import sys

if __name__ == "__main__":
    print("===== HTTP Viewer 数据库结构转换工具 =====")
    print("本工具将把数据库结构转换为README中定义的格式")
    print("\n注意: 操作前会自动备份原始数据库")
    
    # 检查是否有自动确认参数
    auto_confirm = len(sys.argv) > 1 and sys.argv[1] == "--auto-confirm"
    
    if auto_confirm:
        print("\n使用自动确认模式执行转换...")
        main()
    else:
        # 提示用户确认
        confirm = input("\n是否继续执行转换？(y/n): ")
        
        if confirm.lower() == 'y':
            main()
        else:
            print("操作已取消")
