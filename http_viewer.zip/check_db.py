import sqlite3

# 连接到数据库
conn = sqlite3.connect('h:/work/http_viewer/db_log/http.db')
cursor = conn.cursor()

# 获取数据库中的所有表
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("数据库中的表:")
for table in tables:
    print(f"- {table[0]}")
    # 获取表结构
    cursor.execute(f"PRAGMA table_info({table[0]});")
    columns = cursor.fetchall()
    print("  字段信息:")
    for col in columns:
        print(f"  - {col[1]}: {col[2]}")

# 关闭连接
conn.close()