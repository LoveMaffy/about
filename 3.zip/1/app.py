from flask import Flask, render_template, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectMultipleField, BooleanField
from wtforms.validators import DataRequired, Regexp
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cve_versions.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Association table: many-to-many relationship
cve_version = db.Table('cve_version',
    db.Column('cve_id', db.Integer, db.ForeignKey('cve.id'), primary_key=True),
    db.Column('version_id', db.Integer, db.ForeignKey('version.id'), primary_key=True)
)

# CVE Model
class CVE(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cve_id = db.Column(db.String(20), unique=True, nullable=False)
    description = db.Column(db.String(500))
    poc = db.Column(db.String(500))  # POC information
    versions = db.relationship('Version', secondary=cve_version, lazy='subquery',
                               backref=db.backref('cves', lazy=True))

# Version Model
class Version(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    version_name = db.Column(db.String(50), unique=True, nullable=False)
    has_version = db.Column(db.Boolean, default=False)  # Whether the version is owned

# CVE Form
class CVEForm(FlaskForm):
    cve_id = StringField('CVE ID', validators=[
        DataRequired(),
        Regexp(r'^CVE-\d{4}-\d{4,}$', message='Please enter a valid CVE format, e.g., CVE-2025-5777')
    ])
    description = StringField('Description')
    poc = StringField('POC Info')  # POC field
    submit = SubmitField('Submit')

# Version Form
class VersionForm(FlaskForm):
    version_name = StringField('Version', validators=[DataRequired()])
    has_version = BooleanField('Owned')  # Changed to boolean field
    submit = SubmitField('Submit')

# Association Form
class AssociationForm(FlaskForm):
    submit = SubmitField('Associate')

# Initialize database
with app.app_context():
    db.create_all()

# Home page
@app.route('/')
def index():
    return render_template('index.html')

# CVE list
@app.route('/cve_list', methods=['GET', 'POST'])
def cve_list():
    # Create form object
    add_form = CVEForm()
    
    # Handle search
    search_query = request.args.get('search', '').strip()
    if search_query:
        # Convert to uppercase for fuzzy search
        search_query = search_query.upper()
        cves = CVE.query.filter(CVE.cve_id.contains(search_query)).all()
    else:
        cves = CVE.query.all()
    
    # Form submission will be handled by add_cve route
    
    return render_template('cve_list.html', cves=cves, add_form=add_form)

# Version list
@app.route('/version_list', methods=['GET', 'POST'])
def version_list():
    # Create form object
    add_form = VersionForm()
    
    # Handle search
    search_query = request.args.get('search', '').strip()
    if search_query:
        versions = Version.query.filter(Version.version_name.contains(search_query)).all()
    else:
        versions = Version.query.all()
    
    # Form submission will be handled by add_version route
    
    return render_template('version_list.html', versions=versions, add_form=add_form)

# Add CVE
@app.route('/add_cve', methods=['GET', 'POST'])
def add_cve():
    form = CVEForm()
    # Get all versions
    all_versions = Version.query.all()
    
    if form.validate_on_submit():
        # Convert to uppercase
        cve_id = form.cve_id.data.upper()
        # Check if exists
        existing_cve = CVE.query.filter_by(cve_id=cve_id).first()
        if existing_cve:
            return render_template('add_cve.html', form=form, versions=all_versions, error='This CVE already exists')
        
        new_cve = CVE(cve_id=cve_id, description=form.description.data, poc=form.poc.data)
        
        # Process version associations (by version names)
        version_names_input = request.form.get('version_names', '').strip()
        if version_names_input:
            # Split version names and remove whitespace
            version_names = [v.strip() for v in version_names_input.split(',') if v.strip()]
            # Find existing versions
            selected_versions = Version.query.filter(Version.version_name.in_(version_names)).all()
            # Check if all input versions exist
            found_version_names = {v.version_name for v in selected_versions}
            missing_versions = [v for v in version_names if v not in found_version_names]
            
            if missing_versions:
                return render_template('add_cve.html', form=form, versions=all_versions, 
                                     error=f"The following versions do not exist: {', '.join(missing_versions)}")
            
            new_cve.versions = selected_versions
        
        db.session.add(new_cve)
        db.session.commit()
        return redirect(url_for('cve_list'))
    
    return render_template('add_cve.html', form=form, versions=all_versions)

# Edit CVE
@app.route('/edit_cve/<int:cve_id>', methods=['GET', 'POST'])
def edit_cve(cve_id):
    cve = CVE.query.get_or_404(cve_id)
    form = CVEForm(obj=cve)
    # Get all versions
    all_versions = Version.query.all()
    
    if form.validate_on_submit():
        # Convert to uppercase
        new_cve_id = form.cve_id.data.upper()
        # Check for conflicts with other CVEs
        if new_cve_id != cve.cve_id:
            existing_cve = CVE.query.filter_by(cve_id=new_cve_id).first()
            if existing_cve:
                return render_template('edit_cve.html', form=form, cve=cve, versions=all_versions, error='This CVE already exists')
        
        cve.cve_id = new_cve_id
        cve.description = form.description.data
        cve.poc = form.poc.data
        
        # Process version associations (by version names)
        version_names_input = request.form.get('version_names', '').strip()
        if version_names_input:
            # Split version names and remove whitespace
            version_names = [v.strip() for v in version_names_input.split(',') if v.strip()]
            # Find existing versions
            selected_versions = Version.query.filter(Version.version_name.in_(version_names)).all()
            # Check if all input versions exist
            found_version_names = {v.version_name for v in selected_versions}
            missing_versions = [v for v in version_names if v not in found_version_names]
            
            if missing_versions:
                return render_template('edit_cve.html', form=form, cve=cve, versions=all_versions, 
                                     error=f"The following versions do not exist: {', '.join(missing_versions)}")
            
            cve.versions = selected_versions
        else:
            # Clear associations if no versions provided
            cve.versions = []
        
        db.session.commit()
        return redirect(url_for('cve_detail', cve_id=cve.id))
    
    return render_template('edit_cve.html', form=form, cve=cve, versions=all_versions)

# Delete CVE
@app.route('/delete_cve/<int:cve_id>')
def delete_cve(cve_id):
    cve = CVE.query.get_or_404(cve_id)
    db.session.delete(cve)
    db.session.commit()
    return redirect(url_for('cve_list'))

# CVE detail
@app.route('/cve_detail/<int:cve_id>')
def cve_detail(cve_id):
    cve = CVE.query.get_or_404(cve_id)
    # Check if any associated version is owned
    can_reproduce = False
    if cve.versions:
        can_reproduce = any(version.has_version for version in cve.versions)
    return render_template('cve_detail.html', cve=cve, can_reproduce=can_reproduce)

# Add version
@app.route('/add_version', methods=['GET', 'POST'])
def add_version():
    form = VersionForm()
    
    if form.validate_on_submit():
        version_name = form.version_name.data
        # Check if exists
        existing_version = Version.query.filter_by(version_name=version_name).first()
        if existing_version:
            return render_template('add_version.html', form=form, error='This version already exists')
        
        new_version = Version(version_name=version_name, has_version=form.has_version.data)
        db.session.add(new_version)
        db.session.commit()
        return redirect(url_for('version_list'))
    
    return render_template('add_version.html', form=form)

# Edit version
@app.route('/edit_version/<int:version_id>', methods=['GET', 'POST'])
def edit_version(version_id):
    version = Version.query.get_or_404(version_id)
    form = VersionForm(obj=version)
    
    if form.validate_on_submit():
        new_version_name = form.version_name.data
        # Check for conflicts with other versions
        if new_version_name != version.version_name:
            existing_version = Version.query.filter_by(version_name=new_version_name).first()
            if existing_version:
                return render_template('edit_version.html', form=form, version=version, error='This version already exists')
        
        version.version_name = new_version_name
        version.has_version = form.has_version.data
        db.session.commit()
        return redirect(url_for('version_detail', version_id=version.id))
    
    return render_template('edit_version.html', form=form, version=version)

# Delete version
@app.route('/delete_version/<int:version_id>')
def delete_version(version_id):
    version = Version.query.get_or_404(version_id)
    db.session.delete(version)
    db.session.commit()
    return redirect(url_for('version_list'))

# Import versions
@app.route('/import_versions', methods=['GET', 'POST'])
def import_versions():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(url_for('version_list', error='No file selected'))
        
        file = request.files['file']
        if file.filename == '':
            return redirect(url_for('version_list', error='No file selected'))
        
        if not file.filename.endswith('.txt'):
            return redirect(url_for('version_list', error='Please upload a TXT format file'))
        
        try:
            # Read file content
            content = file.read().decode('utf-8')
            versions = content.strip().split('\n')
            
            # Import versions
            imported_count = 0
            existing_count = 0
            for version_name in versions:
                version_name = version_name.strip()
                if version_name:
                    # Check if exists
                    existing = Version.query.filter_by(version_name=version_name).first()
                    if not existing:
                        new_version = Version(version_name=version_name, has_version=False)  # Imported versions are set as not owned by default
                        db.session.add(new_version)
                        imported_count += 1
                    else:
                        existing_count += 1
            
            db.session.commit()
            return redirect(url_for('version_list', message=f'Import successful! New versions: {imported_count}, Existing versions: {existing_count}'))
            
        except Exception as e:
            db.session.rollback()
            return redirect(url_for('version_list', error=f'Import failed: {str(e)}'))
    
    # GET request renders import page
    return render_template('import_versions.html')

# Manage CVE versions
@app.route('/manage_cve_versions/<int:cve_id>', methods=['GET', 'POST'])
def manage_cve_versions(cve_id):
    cve = CVE.query.get_or_404(cve_id)
    form = AssociationForm()
    
    # Get all versions not yet associated with this CVE
    available_versions = Version.query.filter(~Version.cves.contains(cve)).all()
    
    if form.validate_on_submit():
        # Get selected version IDs
        selected_version_ids = request.form.getlist('version_ids')
        
        if selected_version_ids:
            # Add associations
            for version_id in selected_version_ids:
                version = Version.query.get(version_id)
                if version:
                    cve.versions.append(version)
            
            db.session.commit()
        
        return redirect(url_for('cve_detail', cve_id=cve.id))
    
    return render_template('manage_cve_versions.html', cve=cve, form=form, available_versions=available_versions)

# Manage version CVEs
@app.route('/manage_version_cves/<int:version_id>', methods=['GET', 'POST'])
def manage_version_cves(version_id):
    version = Version.query.get_or_404(version_id)
    form = AssociationForm()
    
    # Get all CVEs not yet associated with this version
    available_cves = CVE.query.filter(~CVE.versions.contains(version)).all()
    
    if form.validate_on_submit():
        # Get selected CVE IDs
        selected_cve_ids = request.form.getlist('cve_ids')
        
        if selected_cve_ids:
            # Add associations
            for cve_id in selected_cve_ids:
                cve = CVE.query.get(cve_id)
                if cve:
                    version.cves.append(cve)
            
            db.session.commit()
        
        return redirect(url_for('version_detail', version_id=version.id))
    
    return render_template('manage_version_cves.html', version=version, form=form, available_cves=available_cves)

# Remove CVE version association
@app.route('/remove_cve_version/<int:cve_id>/<int:version_id>')
def remove_cve_version(cve_id, version_id):
    cve = CVE.query.get_or_404(cve_id)
    version = Version.query.get_or_404(version_id)
    
    if version in cve.versions:
        cve.versions.remove(version)
        db.session.commit()
    
    return redirect(url_for('cve_detail', cve_id=cve.id))

# Version detail
@app.route('/version_detail/<int:version_id>')
def version_detail(version_id):
    version = Version.query.get_or_404(version_id)
    return render_template('version_detail.html', version=version)

# Search function
@app.route('/search', methods=['GET', 'POST'])
def search():
    results = []
    search_type = ''
    query = ''
    
    if request.method == 'POST':
        search_type = request.form.get('search_type')
        query = request.form.get('query', '').strip()
        
        if search_type == 'cve':
            # Convert to uppercase for search
            query = query.upper()
            results = CVE.query.filter(CVE.cve_id.contains(query)).all()
        elif search_type == 'version':
            results = Version.query.filter(Version.version_name.contains(query)).all()
    
    return render_template('search.html', results=results, search_type=search_type, query=query)

if __name__ == '__main__':
    app.run(debug=True)